PARAMS = {
    "fast_ema":          9,
    "slow_ema":          21,
    "atr_period":        14,
    "atr_multiplier":    2.0,
    "rr_ratio":          2.0,
    # Macro filters (False = disabled, flip to True to activate)
    "use_vix_filter":    False,   "vix_max":       25.0,
    "use_spx_filter":    False,   "spx_period":    50,
    "use_dxy_filter":    False,   "dxy_period":    20,
    "use_yields_filter": False,   "yields_period": 20,
    "use_gold_filter":   False,   "gold_period":   20,
}
