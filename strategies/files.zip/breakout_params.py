PARAMS = {
    "lookback":          20,
    "atr_period":        14,
    "atr_multiplier":    1.5,
    "volume_factor":     1.5,
    "stop_atr_mult":     1.0,
    "rr_ratio":          3.0,
    # Macro filters
    "use_vix_filter":    False,   "vix_max":       25.0,
    "use_spx_filter":    False,   "spx_period":    50,
    "use_dxy_filter":    False,   "dxy_period":    20,
    "use_yields_filter": False,   "yields_period": 20,
    "use_gold_filter":   False,   "gold_period":   20,
}
