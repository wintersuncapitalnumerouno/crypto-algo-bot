PARAMS = {
    "bb_period":         20,
    "bb_std":            2.0,
    "atr_period":        14,
    "dvol_period":       10,
    "stop_pct":          0.01,
    "rr_ratio":          3.0,
    "trailing_pct":      0.01,
    "trail_trigger":     1.0,
    # Macro filters
    "use_vix_filter":    False,   "vix_max":       25.0,
    "use_spx_filter":    False,   "spx_period":    50,
    "use_dxy_filter":    False,   "dxy_period":    20,
    "use_yields_filter": False,   "yields_period": 20,
    "use_gold_filter":   False,   "gold_period":   20,
}
