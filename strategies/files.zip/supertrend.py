# =============================================================
# strategies/supertrend/supertrend.py
# =============================================================
# STATUS: SKELETON — signal logic to be built per design session
# Edit params in strategies/supertrend/params.py
# =============================================================

import pandas as pd
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from strategies.supertrend.params import PARAMS
from strategies.macro_filters      import load_macro, risk_on_filter


def generate_signals(df: pd.DataFrame, params: dict = None) -> pd.DataFrame:
    if params is None:
        params = PARAMS

    df = df.copy()

    # ── TODO: Add indicators here ────────────────────────────
    # df["ema_fast"] = ...
    # df["atr"]      = ...

    # ── Macro filter ──────────────────────────────────────────
    macro   = load_macro(df.index)
    risk_on = risk_on_filter(macro, params)

    # ── TODO: Define entry conditions ────────────────────────
    long_signal  = pd.Series(False, index=df.index)  # replace with real logic
    short_signal = pd.Series(False, index=df.index)  # replace with real logic

    # Apply macro filter to longs only (shorts can trade risk-off)
    long_signal  = long_signal & risk_on

    df["signal"] = 0
    df.loc[long_signal,  "signal"] =  1
    df.loc[short_signal, "signal"] = -1

    # ── TODO: Define stop loss & take profit ─────────────────
    df["stop_loss_long"]    = df["close"] * (1 - params.get("stop_pct", 0.01))
    df["take_profit_long"]  = df["close"] * (1 + params.get("stop_pct", 0.01) * params.get("rr_ratio", 3.0))
    df["stop_loss_short"]   = df["close"] * (1 + params.get("stop_pct", 0.01))
    df["take_profit_short"] = df["close"] * (1 - params.get("stop_pct", 0.01) * params.get("rr_ratio", 3.0))

    return df.iloc[20:]   # warmup


def get_entries_exits(df: pd.DataFrame, params: dict = None):
    if params is None:
        params = PARAMS
    df            = generate_signals(df, params)
    long_entries  = df["signal"] == 1
    short_entries = df["signal"] == -1
    long_exits    = short_entries
    short_exits   = long_entries
    return long_entries, long_exits, short_entries, short_exits, df
