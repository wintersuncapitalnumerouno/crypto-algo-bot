# =============================================================
# strategies/registry.py — Strategy Registry
# =============================================================
# NO params here. Each strategy owns its own params.py.
# To add a strategy: create the folder + params.py + strategy.py
# then add one entry below.
# =============================================================

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

def _try_import(module_path, fn_name="get_entries_exits"):
    try:
        import importlib
        mod = importlib.import_module(module_path)
        return getattr(mod, fn_name), True
    except Exception:
        return None, False

def _try_params(module_path):
    try:
        import importlib
        mod = importlib.import_module(module_path)
        return mod.PARAMS
    except Exception:
        return {}

# ── Import strategies ─────────────────────────────────────────
_momentum_fn,   _has_momentum   = _try_import("strategies.momentum.momentum")
_breakout_fn,   _has_breakout   = _try_import("strategies.breakout.breakout")
_supertrend_fn, _has_supertrend = _try_import("strategies.supertrend.supertrend")
_dvol_bb_fn,    _has_dvol_bb    = _try_import("strategies.dvol_bb.dvol_bb")

REGISTRY = {

    "Momentum": {
        "fn":          _momentum_fn,
        "params":      _try_params("strategies.momentum.params"),
        "description": "EMA crossover (9/21) — skeleton",
        "enabled":     _has_momentum,
    },

    "Breakout": {
        "fn":          _breakout_fn,
        "params":      _try_params("strategies.breakout.params"),
        "description": "Range breakout + volume — skeleton",
        "enabled":     _has_breakout,
    },

    "SuperTrend": {
        "fn":          _supertrend_fn,
        "params":      _try_params("strategies.supertrend.params"),
        "description": "SuperTrend ATR trend-following — skeleton",
        "enabled":     _has_supertrend,
    },

    "DVOL_BB": {
        "fn":          _dvol_bb_fn,
        "params":      _try_params("strategies.dvol_bb.params"),
        "description": "Bollinger Bands + DVOL bias — skeleton",
        "enabled":     _has_dvol_bb,
    },

    # ── Add new strategies below ──────────────────────────────
    # "BBSqueeze": {
    #     "fn":      _bb_squeeze_fn,
    #     "params":  _try_params("strategies.bb_squeeze.params"),
    #     "enabled": _has_bb_squeeze,
    # },
}


def get_strategies(names=None):
    active = {k: v for k, v in REGISTRY.items() if v["enabled"] and v["fn"] is not None}
    if names:
        unknown = [n for n in names if n not in REGISTRY]
        if unknown:
            raise ValueError(f"Unknown strategies: {unknown}. Available: {list(REGISTRY.keys())}")
        active = {k: v for k, v in active.items() if k in names}
    return active


def list_strategies():
    print("\n📋 Strategy Registry:")
    print(f"  {'Name':<15} {'Status':<10} {'Description'}")
    print("  " + "─" * 60)
    for name, cfg in REGISTRY.items():
        status = "✅ ON " if cfg["enabled"] and cfg["fn"] else "❌ OFF"
        print(f"  {name:<15} {status:<10} {cfg['description']}")
    print()


if __name__ == "__main__":
    list_strategies()
