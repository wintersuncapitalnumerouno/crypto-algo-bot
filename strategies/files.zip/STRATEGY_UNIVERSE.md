# 🧠 Strategy Universe — crypto-algo-bot
> Full menu of what you can build. Use this to design each strategy before coding.

---

## 📐 Strategy Types

| Type | Idea | Best Market | Examples |
|---|---|---|---|
| **Trend Following** | Ride the trend until it ends | Trending (bull/bear) | EMA cross, SuperTrend, ADX |
| **Mean Reversion** | Price moves away from mean → fades back | Ranging/sideways | Bollinger Bands, RSI extremes, Z-score |
| **Breakout** | Price breaks a key level with conviction | Consolidating → explosive | Donchian, ATR breakout, volume breakout |
| **Momentum** | Strong move = more strong move | Trending | ROC, RSI momentum, price acceleration |
| **Volatility Expansion** | Trade the explosion when vol compresses | Low vol → high vol | BB squeeze, ATR expansion, Keltner |
| **Market Making** | Buy bid, sell ask, capture spread | Ranging | Grid trading, ladder orders |
| **Statistical Arb** | Exploit relationship between assets | Any | Pairs trading, cointegration |
| **Regime-Based** | Different strategy for different market states | Any | DVOL regime, trend/range detection |
| **ML-Based** | Use model predictions as signals | Any | Random Forest, LSTM, XGBoost |

---

## 📊 Indicators Available

### Trend
| Indicator | What it measures | Signal |
|---|---|---|
| **EMA** (9, 21, 50, 200) | Smoothed price trend | Cross above/below |
| **SMA** | Simple average | Cross, support/resistance |
| **DEMA** | Double EMA, less lag | Cross above/below |
| **TEMA** | Triple EMA, even less lag | Cross above/below |
| **SuperTrend** | ATR-based trend band | Flip direction |
| **Ichimoku Cloud** | Multi-component trend system | Price vs cloud, cross |
| **MACD** | Momentum + trend | Signal line cross, histogram |
| **ADX** | Trend strength (not direction) | ADX > 25 = strong trend |
| **Parabolic SAR** | Trailing stop + trend | Dot flips side |

### Momentum
| Indicator | What it measures | Signal |
|---|---|---|
| **RSI** (14) | Overbought/oversold | < 30 long, > 70 short |
| **Stochastic** | Price position in range | %K/%D cross |
| **CCI** | Deviation from average | Extremes ±100 |
| **ROC** | Rate of change | Zero cross, extremes |
| **Williams %R** | Similar to Stochastic | Extremes |
| **MFI** | RSI with volume | < 20 long, > 80 short |

### Volatility
| Indicator | What it measures | Signal |
|---|---|---|
| **ATR** | Absolute volatility | Stop sizing, breakout filter |
| **Bollinger Bands** | Relative volatility bands | Touch bands, squeeze |
| **Keltner Channel** | ATR-based bands | Break above/below |
| **BB Squeeze** | BB inside Keltner = compression | Expansion after squeeze |
| **Historical Vol** | Realized volatility | Compare to implied |
| **DVOL** | BTC implied vol index | Rising/falling trend |

### Volume
| Indicator | What it measures | Signal |
|---|---|---|
| **Volume SMA** | Average volume | Spike = confirmation |
| **OBV** | Cumulative vol direction | Divergence with price |
| **VWAP** | Volume-weighted price | Price vs VWAP |
| **Volume Profile** | Vol at price levels | HVN/LVN zones |
| **Funding Rate** | Perp market sentiment | Extreme = contrarian |
| **CVD** | Cumulative volume delta | Divergence |

### Support / Resistance
| Indicator | What it measures | Signal |
|---|---|---|
| **Pivot Points** | Key daily/weekly levels | Bounce or break |
| **Donchian Channel** | N-period high/low | Breakout |
| **Fibonacci** | Retracement levels | Bounce at key levels |
| **VWAP Bands** | SD bands around VWAP | Mean reversion |
| **Round numbers** | Psychological levels | Reaction zones |

---

## 🌍 Macro Filters (your IBKR data)

| Data | Column | Use as filter |
|---|---|---|
| **VIX** | `VIX_close` | VIX > 25 → avoid longs / VIX < 15 → breakouts fail |
| **SPX** | `SPX_close` | SPX uptrend → risk-on → favor longs |
| **DXY** | `DXY_close` | DXY rising → crypto headwind → short bias |
| **US10Y** | `US10Y_close` | Yields rising fast → risk-off → cautious |
| **GLD** | `GLD_close` | GLD rising → flight to safety → risk-off |

---

## 🔗 Signal Combinations (what you can mix)

### Entry conditions (mix and match)
```
PRIMARY signal     +    CONFIRMATION    +    MACRO FILTER
─────────────────────────────────────────────────────────
BB touch lower     +    RSI < 40        +    VIX < 25
EMA cross up       +    ADX > 25        +    SPX uptrend
SuperTrend flip    +    Volume spike    +    DXY falling
Donchian break     +    MACD histogram  +    DVOL falling
RSI divergence     +    OBV confirm     +    GLD flat
BB squeeze break   +    ATR expansion   +    VIX < 20
```

### Exit conditions (pick one or combine)
```
TAKE PROFIT        STOP LOSS           TRAILING           TIME
───────────────────────────────────────────────────────────────
Fixed RR (2:1)     Fixed % (1%)        ATR trail          8h max
Opposite band      ATR-based           Chandelier exit    Session end
Middle BB          SuperTrend band     Parabolic SAR      N candles
Next S/R level     Swing high/low      Step trail         Daily close
```

---

## 🏗️ Your 4 Strategies — Skeleton Plan

### 1. Momentum (EMA Cross)
- **Status:** Working, needs macro filter
- **Add:** SPX trend confirmation, ADX strength filter
- **Macro:** SPX uptrend for longs, downtrend for shorts

### 2. Breakout (Donchian + Volume)
- **Status:** Working, needs macro filter  
- **Add:** VIX filter (avoid high vol), BB squeeze pre-condition
- **Macro:** VIX < 25 for longs, avoid breakouts when VIX spikes

### 3. SuperTrend
- **Status:** Working, needs macro filter
- **Add:** ADX confirmation (only trade when trend is strong)
- **Macro:** DXY + US10Y risk-off filter

### 4. DVOL + BB (new)
- **Status:** Skeleton built
- **Add:** RSI confirmation, funding rate filter
- **Macro:** VIX confirmation of DVOL signal

---

## 💡 New Strategy Ideas to Consider Later

| Name | Logic | Edge |
|---|---|---|
| **BB Squeeze** | BB inside Keltner → wait → trade the explosion | Catches big moves after compression |
| **Funding Fade** | Extreme funding rate → fade the crowd | Contrarian, works in perp markets |
| **VWAP Reversion** | Price far from VWAP → mean revert | Works well intraday |
| **RSI Divergence** | Price makes new high, RSI doesn't → reversal | Catches tops/bottoms |
| **Ichimoku Trend** | Full Ichimoku system | Classic, multi-confirmation |
| **Volatility Breakout** | ATR expands after compression → momentum | Good for crypto explosions |
| **Multi-TF Momentum** | 1h trend + 5m entry | Higher quality signals |
| **SPX Correlation** | Trade BTC when SPX gives signal | Uses macro edge |

---

## 📁 Recommended File Structure

```
strategies/
├── macro_filters.py          ← shared macro loader (VIX, SPX, DXY, etc.)
├── registry.py               ← imports only, no params
│
├── momentum/
│   ├── momentum.py           ← signal logic
│   └── params.py             ← ALL params self-contained here
│
├── breakout/
│   ├── breakout.py
│   └── params.py
│
├── supertrend/
│   ├── supertrend.py
│   └── params.py
│
└── dvol_bb/
    ├── dvol_bb.py
    └── params.py
```

Each `params.py` looks like:
```python
PARAMS = {
    "bb_period":     20,
    "bb_std":        2.0,
    "atr_period":    14,
    # Macro filters
    "vix_max":       25,       # Don't trade if VIX above this
    "spx_trend":     True,     # Require SPX uptrend for longs
    # Risk
    "stop_pct":      0.01,
    "rr_ratio":      3.0,
}
```
