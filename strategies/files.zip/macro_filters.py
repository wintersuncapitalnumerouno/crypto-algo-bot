# =============================================================
# strategies/macro_filters.py — Shared macro data loader
# =============================================================
# Used by ALL strategies. Loads macro_1h.csv and provides
# helper functions to generate filter signals.
#
# Columns in macro_1h.csv:
#   VIX_close, SPX_close, DXY_close, US10Y_close, GLD_close
# =============================================================

import os
import pandas as pd
import numpy as np
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
import config


def load_macro(candle_index: pd.DatetimeIndex) -> pd.DataFrame:
    """
    Load macro_1h.csv and align to candle timeframe via forward-fill.
    Returns empty DataFrame if file not found.
    """
    path = os.path.join(config.DATA_DIR, "macro_1h.csv")
    if not os.path.exists(path):
        return pd.DataFrame(index=candle_index)

    df = pd.read_csv(path, index_col=0, parse_dates=True)
    df.index = pd.to_datetime(df.index, utc=True)
    df = df.reindex(candle_index, method="ffill")
    return df


def vix_filter(macro: pd.DataFrame, vix_max: float = 25.0) -> pd.Series:
    """
    True = VIX is below threshold → OK to trade.
    High VIX = fear/panic = avoid new longs, wider stops needed.
    """
    if "VIX_close" not in macro.columns:
        return pd.Series(True, index=macro.index)
    return macro["VIX_close"] <= vix_max


def spx_trend_filter(macro: pd.DataFrame, period: int = 50) -> pd.Series:
    """
    True = SPX is in uptrend (above its N-period SMA) → risk-on.
    False = SPX downtrend → risk-off, avoid longs.
    """
    if "SPX_close" not in macro.columns:
        return pd.Series(True, index=macro.index)
    sma = macro["SPX_close"].rolling(period).mean()
    return macro["SPX_close"] > sma


def dxy_filter(macro: pd.DataFrame, period: int = 20) -> pd.Series:
    """
    True = DXY is falling or flat → crypto-friendly.
    False = DXY rising strongly → dollar headwind for crypto.
    """
    if "DXY_close" not in macro.columns:
        return pd.Series(True, index=macro.index)
    dxy_sma = macro["DXY_close"].rolling(period).mean()
    return macro["DXY_close"] <= dxy_sma


def yields_filter(macro: pd.DataFrame, period: int = 20) -> pd.Series:
    """
    True = US10Y yield is stable or falling → risk-on.
    False = yields rising sharply → risk-off.
    """
    if "US10Y_close" not in macro.columns:
        return pd.Series(True, index=macro.index)
    y_sma = macro["US10Y_close"].rolling(period).mean()
    return macro["US10Y_close"] <= y_sma


def gold_filter(macro: pd.DataFrame, period: int = 20) -> pd.Series:
    """
    True = GLD is flat or falling → no flight to safety.
    False = GLD rising → risk-off signal.
    """
    if "GLD_close" not in macro.columns:
        return pd.Series(True, index=macro.index)
    gld_sma = macro["GLD_close"].rolling(period).mean()
    return macro["GLD_close"] <= gld_sma


def risk_on_filter(macro: pd.DataFrame, params: dict) -> pd.Series:
    """
    Combined risk-on filter. Returns True = safe to enter longs.
    Each filter is optional — controlled by params.
    """
    index  = macro.index
    result = pd.Series(True, index=index)

    if params.get("use_vix_filter", False):
        result &= vix_filter(macro, params.get("vix_max", 25.0))

    if params.get("use_spx_filter", False):
        result &= spx_trend_filter(macro, params.get("spx_period", 50))

    if params.get("use_dxy_filter", False):
        result &= dxy_filter(macro, params.get("dxy_period", 20))

    if params.get("use_yields_filter", False):
        result &= yields_filter(macro, params.get("yields_period", 20))

    if params.get("use_gold_filter", False):
        result &= gold_filter(macro, params.get("gold_period", 20))

    return result
